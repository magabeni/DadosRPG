package br.com.curso.dadosrpg;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    // 1. Criamos as variáveis para representar os itens da tela
    private TextView txtResultado;
    private Button btnRolar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Liga este código ao XML

        // 2. Fazemos a ponte: O Java encontra o componente pelo ID do XML
        txtResultado = findViewById(R.id.txt_resultado);
        btnRolar = findViewById(R.id.btn_rolar);

        // 3. Programamos o "ouvido" do botão. Ele fica esperando o clique.
        btnRolar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rolarDado(); // Chama a nossa função de sorteio
            }
        });
    }

    private void rolarDado() {
        // 4. Geramos um número aleatório entre 0 e 19 e somamos 1 (resultado: 1 a 20)
        int numeroSorteado = new Random().nextInt(20) + 1;

        // 5. Atualizamos o texto na tela
        // Importante: O setText precisa de uma String (texto), por isso o String.valueOf
        txtResultado.setText(String.valueOf(numeroSorteado));
    }
}
